/* sendSeqNum is decoded as part of the id.msgType element */
