/* start custom code */
/* In case integrity protection check failed and error was not immediately 
   returned. */
ret = rtxErrGetStatus(pctxt);

/* end custom code */
