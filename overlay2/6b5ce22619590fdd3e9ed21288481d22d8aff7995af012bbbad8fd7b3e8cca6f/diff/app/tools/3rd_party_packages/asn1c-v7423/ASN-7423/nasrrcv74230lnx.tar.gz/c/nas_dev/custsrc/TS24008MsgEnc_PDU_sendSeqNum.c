/* sendSeqNum is encoded as part of the id.msgType element */
